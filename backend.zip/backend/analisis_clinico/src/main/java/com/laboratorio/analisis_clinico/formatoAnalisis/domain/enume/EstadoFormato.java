package com.laboratorio.analisis_clinico.formatoAnalisis.domain.enume;

public enum EstadoFormato {
    VIGENTE,
    OBSOLETO
}
