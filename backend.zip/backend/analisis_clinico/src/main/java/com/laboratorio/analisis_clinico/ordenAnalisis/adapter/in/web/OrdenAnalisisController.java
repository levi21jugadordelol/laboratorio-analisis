package com.laboratorio.analisis_clinico.ordenAnalisis.adapter.in.web;

public class OrdenAnalisisController {
}
