package com.laboratorio.analisis_clinico.formatoAnalisis.adapter.in.web;

public class FormatoAnalisisController {
}
