package com.laboratorio.analisis_clinico.areaMedica.adapter.in.web;

public class areaMedicaController {
}
