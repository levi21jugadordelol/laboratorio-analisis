package com.laboratorio.analisis_clinico.auditlog.domain.enume;

public enum ActionAuditlog {
    CREATE,
    UPDATE,
    DELETE,
    VALIDATE
}
