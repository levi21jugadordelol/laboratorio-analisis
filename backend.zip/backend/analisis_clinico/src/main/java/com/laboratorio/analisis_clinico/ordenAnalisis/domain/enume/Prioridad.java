package com.laboratorio.analisis_clinico.ordenAnalisis.domain.enume;

public enum Prioridad {
    NORMAL,
    URGENTE
}
