package com.laboratorio.analisis_clinico.reporte.adapter.in.web;

public class ReporteController {
}
