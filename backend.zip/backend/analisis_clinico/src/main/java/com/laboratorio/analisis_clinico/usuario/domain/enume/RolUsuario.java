package com.laboratorio.analisis_clinico.usuario.domain.enume;

public enum RolUsuario {
    ADMIN,
    LABORATORISTA
}
