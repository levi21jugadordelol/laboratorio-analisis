package com.laboratorio.analisis_clinico.orden.domain.enume;

public enum EstadoOrden {
    CREADA,
    EN_PROCESO,
    FINALIZADA,
    ANULADA
}
