package com.laboratorio.analisis_clinico.personalMedico.domain.enume;

public enum EstadoPersonalMedico {
    ACTIVO,
    INACTIVO
}
