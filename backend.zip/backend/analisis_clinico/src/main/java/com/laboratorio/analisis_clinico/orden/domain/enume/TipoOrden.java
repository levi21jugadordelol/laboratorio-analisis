package com.laboratorio.analisis_clinico.orden.domain.enume;

public enum TipoOrden {
    RECETA,
    PARTICULAR
}
