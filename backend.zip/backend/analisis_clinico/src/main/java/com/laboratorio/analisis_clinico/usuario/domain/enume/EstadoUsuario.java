package com.laboratorio.analisis_clinico.usuario.domain.enume;

public enum EstadoUsuario {
    ACTIVO,
    INACTIVO
}
