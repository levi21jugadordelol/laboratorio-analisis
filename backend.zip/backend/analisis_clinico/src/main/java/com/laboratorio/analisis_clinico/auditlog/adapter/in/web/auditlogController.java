package com.laboratorio.analisis_clinico.auditlog.adapter.in.web;

public class auditlogController {
}
