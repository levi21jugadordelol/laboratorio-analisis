package com.laboratorio.analisis_clinico.analisis.adapter.in.web;

public class WebController {
}
