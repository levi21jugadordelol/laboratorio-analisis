package com.laboratorio.analisis_clinico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalisisClinicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalisisClinicoApplication.class, args);
	}

}
