package com.laboratorio.analisis_clinico.ordenAnalisis.domain.enume;

public enum EstadoOrdenMedicaAnalisis {
    PENDIENTE,
    EN_PROCESO,
    COMPLETADO,
    CANCELADO
}

