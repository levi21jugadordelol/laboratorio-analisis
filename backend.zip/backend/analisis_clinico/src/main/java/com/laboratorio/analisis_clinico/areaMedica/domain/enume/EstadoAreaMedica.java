package com.laboratorio.analisis_clinico.areaMedica.domain.enume;

public enum EstadoAreaMedica {
    ACTIVA,
    INACTIVA

}
