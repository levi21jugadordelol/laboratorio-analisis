package com.laboratorio.analisis_clinico.paciente.adapter.in.web;

public class pacienteController {
}
