package com.laboratorio.analisis_clinico.orden.adapter.in.web;

public class OrdenController {
}
