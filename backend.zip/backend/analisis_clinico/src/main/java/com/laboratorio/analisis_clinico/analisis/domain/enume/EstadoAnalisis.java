package com.laboratorio.analisis_clinico.analisis.domain.enume;

public enum EstadoAnalisis {
    ACTIVO,
    INACTIVO
}
