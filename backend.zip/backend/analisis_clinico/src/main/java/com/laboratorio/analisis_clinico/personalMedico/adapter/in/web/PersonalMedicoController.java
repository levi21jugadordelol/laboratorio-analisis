package com.laboratorio.analisis_clinico.personalMedico.adapter.in.web;

public class PersonalMedicoController {
}
