package com.laboratorio.analisis_clinico.paciente.domain.enume;

public enum TipoPaciente {
    ASEGURADO,
    PARTICULAR,
    ESSALUD
}
