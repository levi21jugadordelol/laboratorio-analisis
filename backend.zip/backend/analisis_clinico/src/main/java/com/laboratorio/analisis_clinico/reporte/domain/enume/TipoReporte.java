package com.laboratorio.analisis_clinico.reporte.domain.enume;

public enum TipoReporte {
    QUINCENAL,
    MENSUAL,
    PACIENTE,
    COMPARATIVO
}
