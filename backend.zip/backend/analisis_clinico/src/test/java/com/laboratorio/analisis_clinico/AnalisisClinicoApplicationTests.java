package com.laboratorio.analisis_clinico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalisisClinicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
